# -*- coding: utf-8 -*-

from . import update_input_path_wizard